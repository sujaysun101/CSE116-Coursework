package tests;

import org.junit.Test;
import ratings.Playlist;
import ratings.Rating;
import ratings.Song;
import ratings.datastructures.BST;
import ratings.datastructures.BinaryTreeNode;
import ratings.datastructures.LinkedListNode;
import ratings.datastructures.SongTitleComparator;

import static org.junit.Assert.*;

public class TestDataStructures2 {

    public boolean compareSongs(Song s1, Song s2) {
        if (s1.getTitle().equals(s2.getTitle()) && s1.getArtist().equals(s2.getArtist()) && s1.getSongID().equals(s2.getSongID())) {
            return true;
        }
        return false;
    }

   public boolean compareSongLists(LinkedListNode<Song> n1, LinkedListNode<Song> n2) {
       if (n1 == null && n2 == null) {
           return true;
       }
       if ((n1 == null && n2 != null) || (n1 != null && n2 == null)) {
           return false;
       }
        assertTrue(compareSongs(n1.getValue(), n2.getValue()));
        compareSongLists(n1.getNext(), n2.getNext());
        return true;
   }

    public void inOrderTraversal(BinaryTreeNode<Song> b1, BinaryTreeNode<Song> b2) {
        if (b1 == null && b2 == null) {
            assertTrue(true);
        }
        else if (b1 == null && b2 != null) {
            assertTrue(false);
        }
        else if (b1 != null && b2 == null) {
            assertTrue(false);
        }
        else {
            inOrderTraversal(b1.getLeft(), b2.getLeft());
            assertTrue(compareSongTrees(b1, b2));
            inOrderTraversal(b1.getRight(), b2.getRight());
        }
    }
    public boolean compareSongTrees(BinaryTreeNode<Song> b1, BinaryTreeNode<Song> b2) {
        inOrderTraversal(b1, b2);
        return true;
    }

    @Test
    public void testAddSong() {
        BST<Song> bst = new BST<>(new SongTitleComparator());
        Song s1 = new Song("a", "b", "3");
        Song s2 = new Song("b", "c", "3");
        Song s3 = new Song("c", "c", "3");
        Song s4 = new Song("d", "b", "3");
        Song s5 = new Song("e", "c", "3");
        Song s6 = new Song("f", "b", "3");
        Song s7 = new Song("aa", "b", "3");
        BinaryTreeNode<Song> root = new BinaryTreeNode<Song>(s1, null, null);
        root.left = new BinaryTreeNode<>(s2, null, null);
        root.right = new BinaryTreeNode<Song>(s3, null, null);
        root.left.left = new BinaryTreeNode<Song>(s4, null, null);
        root.left.right = new BinaryTreeNode<Song>(s5, null, null);
        root.right.left = new BinaryTreeNode<Song>(s6, null, null);
        root.right.right = new BinaryTreeNode<Song>(s7, null, null);
        bst.root = root;

    }

    @Test
    public void testGetSongList() {

        Song s1 = new Song("a", "b", "3");
        Song s2 = new Song("b", "c", "3");
        Song s3 = new Song("c", "c", "3");
        Song s4 = new Song("d", "b", "3");
        Song s5 = new Song("e", "c", "3");
        Song s6 = new Song("f", "b", "3");
        Song s7 = new Song("aa", "b", "3");

        LinkedListNode<Song> n1 = new LinkedListNode<>(s1, null);
        LinkedListNode<Song> n2 = new LinkedListNode<>(s7, n1);
        LinkedListNode<Song> n3 = new LinkedListNode<>(s2, n2);
        LinkedListNode<Song> n4 = new LinkedListNode<>(s3, n3);
        LinkedListNode<Song> n5 = new LinkedListNode<>(s4, n4);
        LinkedListNode<Song> n6 = new LinkedListNode<>(s5, n5);
        LinkedListNode<Song> n7 = new LinkedListNode<>(s6, n6);

        Playlist<Song> p = new Playlist<>(new SongTitleComparator());
        p.addSong(s1);
        p.addSong(s2);
        p.addSong(s3);
        p.addSong(s4);
        p.addSong(s5);
        p.addSong(s6);
        p.addSong(s7);

        TestDataStructures1 dataStructures1 = new TestDataStructures1();

        LinkedListNode<Song> p1 = p.getSongList();
        assertTrue(compareSongLists(n7, p.getSongList()));
    }

    @Test
    public void testGetSongTree() {

        Song s1 = new Song("a", "b", "3");
        Song s2 = new Song("b", "c", "3");
        Song s3 = new Song("c", "c", "3");
        Song s4 = new Song("d", "b", "3");
        Song s5 = new Song("e", "c", "3");
        Song s6 = new Song("f", "b", "3");
        Song s7 = new Song("aa", "b", "3");

        BinaryTreeNode<Song> root = new BinaryTreeNode<Song>(s1, null, null);
        root.left = new BinaryTreeNode<>(s2, null, null);
        root.right = new BinaryTreeNode<Song>(s3, null, null);
        root.left.left = new BinaryTreeNode<Song>(s4, null, null);
        root.left.right = new BinaryTreeNode<Song>(s5, null, null);
        root.right.left = new BinaryTreeNode<Song>(s6, null, null);
        root.right.right = new BinaryTreeNode<Song>(s7, null, null);
        //bst.root = root;

        Playlist<Song> p = new Playlist<>(new SongTitleComparator());

        p.addSong(s1);
        p.addSong(s2);
        p.addSong(s3);
        p.addSong(s4);
        p.addSong(s5);
        p.addSong(s6);
        p.addSong(s7);

        TestDataStructures1 dataStructures1 = new TestDataStructures1();

        assertTrue(compareSongTrees(root, p.getSongTree()));

    }
}