package ratings;

public class Song {
    private String title;
    private String artist;
    private String id;
    public Song(String title, String artist, String id) {
        this.title = title;
        this.artist = artist;
        this.id = id;
    }
    public String getTitle() {
        return this.title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getArtist() {
        return this.artist;
    }
    public void setArtist(String artist) {
        this.artist = artist;
    }
    public String getSongID() {
        return this.id;
    }
    public void setSongID(String id) {
        this.id = id;
    }
}
